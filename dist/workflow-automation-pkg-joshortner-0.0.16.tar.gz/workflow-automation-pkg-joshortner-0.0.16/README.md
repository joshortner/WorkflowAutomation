# Workflow Automation Package 

This package contains scripts to automate some of the things I find myself doing often.

## cmake-man
