from workflow_automation import example


def main():
    print("MAIN FUNCTION")
    print(example.add_one(150))

