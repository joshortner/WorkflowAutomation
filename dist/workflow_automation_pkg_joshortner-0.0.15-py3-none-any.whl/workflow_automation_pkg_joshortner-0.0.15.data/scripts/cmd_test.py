#!python

from workflow_automation import example


def main():
    print(example.add_one(15))


if __name__ == "__main__":
    main()
